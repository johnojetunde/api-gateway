const jwt = require('jsonwebtoken');

const crypto = require('crypto');
const jwksClient = require('jwks-rsa');

const keyClient = jwksClient({
    cache: true,
    cacheMaxAge: 86400000, //value in ms
    rateLimit: true,
    jwksRequestsPerMinute: 10,
    strictSsl: true,
    jwksUri: process.env.JWKS_URI
})

const verificationOptions = {
    // verify claims, e.g.
    // "audience": "urn:audience"
    "algorithms": "RS256"
}


const allow = {
    "principalId": "user",
    "policyDocument": {
        "Version": "2012-10-17",
        "Statement": [
            {
                "Action": "execute-api:Invoke",
                "Effect": "Allow",
                "Resource": process.env.RESOURCE
            }
        ]
    }
}

function getSigningKey (header = decoded.header, callback) {
    keyClient.getSigningKey(header.kid, function(err, key) {
        const signingKey = key.publicKey || key.rsaPublicKey;
        callback(null, signingKey);
    })
}

function extractTokenFromHeader(event) {
     const authorization = event && event.headers && (event.headers['Authorization'] ?? event.headers['authorization'])
    if (authorization && authorization.split(' ')[0] === 'Bearer') {
        return authorization.split(' ')[1];
    } else {
        return authorization;
    }
}

function validateToken(token, callback) {
    return jwt.verify(token, "qwertyuiopasdfghjklzxcvbnm123456", function(error, pauload){
        if(error){
        return undefined;
        }else{
            return pauload;
        }
    })
}

exports.handler = async (event) => {
    // TODO implement
    const token = extractTokenFromHeader(event);
    const requestBody = event && event.body && JSON.parse(event.body);
    //  let encodedToken = jwt.sign(requestBody,"qwertyuiopasdfghjklzxcvbnm123456");
    let decodedToken = jwt.decode(token);
    let claims =  validateToken(token)
    if(isValid(claims)){
        return {
      "principalId": "john", // The principal user identification associated with the token sent by the client.
      "policyDocument": {
        "Version": "2012-10-17",
        "Statement": [{
          "Action": "execute-api:Invoke",
          "Effect": "Allow",
          "Resource": event.routeArn
        }]
      },
      "context": {
        "stringKey": "value",
        "numberKey": 1,
        "booleanKey": true,
        "arrayKey": ["value1", "value2"],
        "mapKey": { "value1": "value2" }
      }
    };
    }else{
            console.log("denied");
    return {
      "principalId": "abcdef", // The principal user identification associated with the token sent by the client.
      "policyDocument": {
        "Version": "2012-10-17",
        "Statement": [{
          "Action": "execute-api:Invoke",
          "Effect": "Deny",
          "Resource": event.routeArn
        }]
      },
      "context": {
        "stringKey": "value",
        "numberKey": 1,
        "booleanKey": true,
        "arrayKey": ["value1", "value2"],
        "mapKey": { "value1": "value2" }
      }
    };
    }
};

function isValid(claims){
    return claims && claims.type ==='OPEN_API';
}
